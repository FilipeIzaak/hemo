package com.hemoglobank.api.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Set;

@Component
public class CustomSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        Set<String> roles = AuthorityUtils.authorityListToSet(authentication.getAuthorities());

        if (roles.contains("ROLE_DOADOR")) {
            response.sendRedirect("/doador/painel");
        } else if (roles.contains("ROLE_MEDICO") || roles.contains("ROLE_FUNCIONARIO") || roles.contains("ROLE_ADMIN")) {
            response.sendRedirect("/medico/painel");
        } else {
            response.sendRedirect("/");
        }
    }
}