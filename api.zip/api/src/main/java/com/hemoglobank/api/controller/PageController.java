package com.hemoglobank.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // <-- Certifique-se de que este import existe
import org.springframework.web.bind.annotation.GetMapping;

import com.hemoglobank.api.model.Usuario;
import com.hemoglobank.api.repository.UsuarioRepository;

@Controller
public class PageController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Página Inicial
    @GetMapping("/")
    public String index() {
        return "index"; 
    }

    @GetMapping("/cadastro")
    public String paginaCadastro() {
        return "cadastro"; 
    }

    // Página de Login
    @GetMapping("/login")
    public String login() {
        return "login"; 
    }

    // Painel do Doador (Único e correto, injetando o Model e o usuário logado)
    @GetMapping("/doador/painel")
    public String painelDoador(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails != null) {
            // Busca o usuário logado pelo e-mail
            Usuario usuario = usuarioRepository.findByEmail(userDetails.getUsername()).orElse(null);
            model.addAttribute("usuario", usuario);
        }
        return "doador/painel"; 
    }

    @GetMapping("/doador/agendamento")
    public String agendamentoDoador() {
        return "doador/agendamento"; 
    }

    // Painel do Médico e Exames
    @GetMapping("/medico/painel")
    public String painelMedico() {
        return "medico/painel"; 
    }

    @GetMapping("/medico/exames")
    public String exameMedico() {
        return "medico/exame"; 
    }
}